# NICO IPTV 0.13

- Vigilancia automática del directo para detectar posición, búfer o imagen congelados.
- Reconexión automática del mismo canal si la señal queda bloqueada durante 12 segundos.
- Búfer ampliado y ajustado para emisiones en directo inestables.
- Previsualización con sonido y tamaño aumentado un 25 %.
- Izquierda y derecha vuelven a funcionar como cursores en TV en directo.
- Los botones Canal + y Canal − del mando Fire TV cambian al canal siguiente o anterior.
