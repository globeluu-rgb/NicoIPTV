# NICO IPTV 0.11

- Marca amarilla y flecha visible sobre el canal, película o serie seleccionado.
- Cambio al canal anterior o siguiente con izquierda/derecha durante la reproducción en directo.
- Películas y Series adoptan la misma interfaz compacta de TV en directo.
- Categorías laterales, lista única, favoritos y búsqueda mediante lupa en las tres secciones.
- Conserva la corrección DNS para Fire TV introducida en la versión 0.10.
