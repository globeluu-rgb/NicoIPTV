package es.nico.iptv;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executor;

final class AppUpdater {
    private static final String LATEST_RELEASE_API =
            "https://api.github.com/repos/globeluu-rgb/NicoIPTV/releases/latest";
    private static final String USER_AGENT = "NicoIPTV-Android/0.6";

    interface Callback {
        void onStatus(String message, boolean busy);
        void onUpdateReady(String version, String notes, String downloadUrl);
        void onCurrent();
        void onError(String message);
    }

    private AppUpdater() { }

    static void check(Executor worker, Activity activity, Callback callback) {
        callback.onStatus("Buscando la última versión…", true);
        worker.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = open(LATEST_RELEASE_API);
                int response = connection.getResponseCode();
                if (response == 404) throw new Exception("Todavía no hay una versión publicada.");
                if (response < 200 || response >= 300) {
                    throw new Exception("GitHub ha respondido con el código " + response + ".");
                }
                String json = readText(connection);
                JSONObject release = new JSONObject(json);
                String version = release.optString("tag_name", "").replaceFirst("^[vV]", "");
                String notes = release.optString("body", "");
                String apkUrl = findApk(release.optJSONArray("assets"));
                if (version.isEmpty() || apkUrl.isEmpty()) {
                    throw new Exception("La publicación no contiene un APK válido.");
                }
                String current = activity.getPackageManager()
                        .getPackageInfo(activity.getPackageName(), 0).versionName;
                if (compareVersions(version, current) <= 0) {
                    activity.runOnUiThread(callback::onCurrent);
                } else {
                    activity.runOnUiThread(() -> callback.onUpdateReady(version, notes, apkUrl));
                }
            } catch (Exception error) {
                activity.runOnUiThread(() -> callback.onError(message(error)));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    static void downloadAndInstall(Executor worker, Activity activity, String version,
                                   String url, Callback callback) {
        callback.onStatus("Descargando NICO IPTV " + version + "…", true);
        worker.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = open(url);
                int response = connection.getResponseCode();
                if (response < 200 || response >= 300) {
                    throw new Exception("No se ha podido descargar el APK (" + response + ").");
                }
                File external = activity.getExternalFilesDir(null);
                if (external == null) throw new Exception("El almacenamiento no está disponible.");
                File directory = new File(external, "updates");
                if (!directory.exists() && !directory.mkdirs()) {
                    throw new Exception("No se ha podido preparar la carpeta de actualización.");
                }
                File apk = new File(directory, "NicoIPTV-" + version + ".apk");
                try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
                     FileOutputStream output = new FileOutputStream(apk)) {
                    byte[] buffer = new byte[32 * 1024];
                    int read;
                    while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                }
                activity.runOnUiThread(() -> install(activity, apk, callback));
            } catch (Exception error) {
                activity.runOnUiThread(() -> callback.onError(message(error)));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static void install(Activity activity, File apk, Callback callback) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    && !activity.getPackageManager().canRequestPackageInstalls()) {
                activity.getPreferences(Activity.MODE_PRIVATE).edit()
                        .putString("pending_update_apk", apk.getAbsolutePath()).apply();
                Intent permission = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(permission);
                callback.onStatus("Autoriza ‘Instalar apps desconocidas’ y vuelve a NICO IPTV.", false);
                return;
            }
            activity.getPreferences(Activity.MODE_PRIVATE).edit()
                    .remove("pending_update_apk").apply();
            Uri uri = FileProvider.getUriForFile(activity,
                    activity.getPackageName() + ".fileprovider", apk);
            Intent installer = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(installer);
            callback.onStatus("Se ha abierto el instalador de Android.", false);
        } catch (Exception error) {
            callback.onError(message(error));
        }
    }

    static void resumePendingInstall(Activity activity, Callback callback) {
        String path = activity.getPreferences(Activity.MODE_PRIVATE)
                .getString("pending_update_apk", "");
        if (path.isEmpty()) return;
        File apk = new File(path);
        if (apk.isFile() && (Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                || activity.getPackageManager().canRequestPackageInstalls())) {
            install(activity, apk, callback);
        }
    }

    private static HttpURLConnection open(String url) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "application/vnd.github+json");
        connection.setRequestProperty("User-Agent", USER_AGENT);
        return connection;
    }

    private static String readText(HttpURLConnection connection) throws Exception {
        try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            return output.toString("UTF-8");
        }
    }

    private static String findApk(JSONArray assets) {
        if (assets == null) return "";
        for (int i = 0; i < assets.length(); i++) {
            JSONObject asset = assets.optJSONObject(i);
            if (asset == null) continue;
            String name = asset.optString("name", "");
            if (name.toLowerCase(java.util.Locale.ROOT).endsWith(".apk")) {
                return asset.optString("browser_download_url", "");
            }
        }
        return "";
    }

    static int compareVersions(String left, String right) {
        String[] a = left.split("[^0-9]+");
        String[] b = right.split("[^0-9]+");
        int length = Math.max(a.length, b.length);
        for (int i = 0; i < length; i++) {
            int x = number(a, i);
            int y = number(b, i);
            if (x != y) return Integer.compare(x, y);
        }
        return 0;
    }

    private static int number(String[] values, int index) {
        if (index >= values.length || values[index].isEmpty()) return 0;
        try { return Integer.parseInt(values[index]); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private static String message(Exception error) {
        String value = error.getMessage();
        return value == null || value.trim().isEmpty() ? "Error de actualización." : value;
    }
}
