package es.nico.iptv;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Persistent Xtream profiles. Passwords are encrypted with a device-bound Keystore key. */
final class AccountStore {
    static final class Account {
        final String id;
        final String name;
        final String server;
        final String username;
        final String password;

        Account(String id, String name, String server, String username, String password) {
            this.id = id;
            this.name = name;
            this.server = server;
            this.username = username;
            this.password = password;
        }
    }

    private static final String STORE = "nico_accounts_v4";
    private static final String ACCOUNTS = "accounts";
    private static final String ACTIVE = "active_account";
    private static final String KEY_ALIAS = "nico_iptv_accounts_v1";
    private final SharedPreferences prefs;

    AccountStore(Context context) {
        prefs = context.getSharedPreferences(STORE, Context.MODE_PRIVATE);
        migrateLegacy(context);
    }

    List<Account> all() {
        ArrayList<Account> result = new ArrayList<>();
        try {
            JSONArray rows = new JSONArray(prefs.getString(ACCOUNTS, "[]"));
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                String password;
                try {
                    password = decrypt(row.optString("password"));
                } catch (Exception ignored) {
                    continue;
                }
                result.add(new Account(row.optString("id"), row.optString("name"),
                        row.optString("server"), row.optString("username"), password));
            }
        } catch (Exception ignored) { }
        return result;
    }

    Account active() {
        String activeId = prefs.getString(ACTIVE, "");
        if (activeId.isEmpty()) return null;
        return find(activeId);
    }

    Account find(String id) {
        for (Account account : all()) if (account.id.equals(id)) return account;
        return null;
    }

    Account save(String existingId, String name, String server, String username, String password)
            throws Exception {
        String id = existingId == null || existingId.isEmpty()
                ? UUID.randomUUID().toString() : existingId;
        Account updated = new Account(id, name, server, username, password);
        List<Account> accounts = all();
        boolean replaced = false;
        for (int i = 0; i < accounts.size(); i++) {
            if (accounts.get(i).id.equals(id)) {
                accounts.set(i, updated);
                replaced = true;
                break;
            }
        }
        if (!replaced) accounts.add(updated);
        write(accounts);
        return updated;
    }

    void setActive(String id) {
        prefs.edit().putString(ACTIVE, id == null ? "" : id).commit();
    }

    void delete(String id) throws Exception {
        List<Account> accounts = all();
        for (int i = accounts.size() - 1; i >= 0; i--) {
            if (accounts.get(i).id.equals(id)) accounts.remove(i);
        }
        write(accounts);
        if (id.equals(prefs.getString(ACTIVE, ""))) setActive(null);
    }

    private void write(List<Account> accounts) throws Exception {
        JSONArray rows = new JSONArray();
        for (Account account : accounts) {
            JSONObject row = new JSONObject();
            row.put("id", account.id);
            row.put("name", account.name);
            row.put("server", account.server);
            row.put("username", account.username);
            row.put("password", encrypt(account.password));
            rows.put(row);
        }
        if (!prefs.edit().putString(ACCOUNTS, rows.toString()).commit()) {
            throw new IllegalStateException("No se ha podido guardar la cuenta");
        }
    }

    private void migrateLegacy(Context context) {
        if (prefs.getBoolean("legacy_migrated", false)) return;
        SharedPreferences legacy = context.getSharedPreferences("nico_xtream", Context.MODE_PRIVATE);
        String server = legacy.getString("server", "");
        String username = legacy.getString("username", "");
        String password = legacy.getString("password", "");
        try {
            if (!server.isEmpty() && !username.isEmpty() && !password.isEmpty() && all().isEmpty()) {
                Account account = save(null, username, server, username, password);
                setActive(account.id);
            }
            prefs.edit().putBoolean("legacy_migrated", true).commit();
            legacy.edit().remove("server").remove("username").remove("password").apply();
        } catch (Exception ignored) { }
    }

    private SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) store.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private String encrypt(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + "."
                + Base64.encodeToString(encrypted, Base64.NO_WRAP);
    }

    private String decrypt(String value) throws Exception {
        String[] parts = value.split("\\.", 2);
        if (parts.length != 2) throw new IllegalArgumentException("Credencial dañada");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(),
                new GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)),
                StandardCharsets.UTF_8);
    }
}
