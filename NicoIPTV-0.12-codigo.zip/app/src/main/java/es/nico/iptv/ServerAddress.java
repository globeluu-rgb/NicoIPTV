package es.nico.iptv;

import java.net.URI;
import java.util.Locale;

final class ServerAddress {
    private ServerAddress() { }

    static String normalize(String value) throws Exception {
        String cleaned = value == null ? "" : value.trim();
        cleaned = cleaned.replaceFirst("/0\\.0\\.0\\.0:80/?$", "").replaceAll("/+$", "");
        URI uri = new URI(cleaned);
        String scheme = uri.getScheme();
        if (!("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))
                || uri.getHost() == null || uri.getUserInfo() != null
                || uri.getQuery() != null || uri.getFragment() != null
                || "0.0.0.0".equals(uri.getHost())) {
            throw new IllegalArgumentException("Servidor no válido. Usa http://dominio:puerto");
        }
        String path = uri.getRawPath() == null ? "" : uri.getRawPath().replaceAll("/{2,}", "/");
        path = path.replaceAll("/+$", "");
        return scheme.toLowerCase(Locale.ROOT) + "://" + uri.getRawAuthority() + path;
    }
}
