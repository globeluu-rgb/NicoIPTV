package es.nico.iptv;
import java.io.*;
import java.net.URI;
import java.util.*;
import java.util.regex.*;
public final class Playlist {
 public static class Channel { public final String name,group,url; Channel(String n,String g,String u){name=n;group=g;url=u;} }
 public static List<Channel> parse(Reader source,String base) throws IOException {
  List<Channel> out=new ArrayList<>(); BufferedReader r=new BufferedReader(source); String line,name=null,group="Sin grupo";
  while((line=r.readLine())!=null){line=line.trim().replace("\uFEFF",""); if(line.isEmpty())continue;
   if(line.startsWith("#EXTINF:")){int comma=-1; boolean quoted=false; for(int i=0;i<line.length();i++){if(line.charAt(i)=='"')quoted=!quoted; if(line.charAt(i)==','&&!quoted){comma=i;break;}} name=comma>=0?line.substring(comma+1).trim():"Canal"; Matcher m=Pattern.compile("group-title=\"([^\"]*)\"").matcher(line);group=m.find()?m.group(1):"Sin grupo";}
   else if(!line.startsWith("#")){try {URI u=URI.create(base).resolve(line);if("https".equalsIgnoreCase(u.getScheme())||"http".equalsIgnoreCase(u.getScheme()))out.add(new Channel(name==null?"Canal "+(out.size()+1):name,group,u.toString()));}catch(IllegalArgumentException ignored){}name=null;group="Sin grupo";if(out.size()>50000)throw new IOException("Lista demasiado grande");}
  }return out;
 }
}
