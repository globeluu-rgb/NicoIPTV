# NICO IPTV 0.4 — cambios y verificación

## Cambios aplicados

- Nueva sección **Cuentas** con varios perfiles Xtream.
- Acciones Añadir, Editar, Conectar, Desconectar y Eliminar.
- Confirmación antes de eliminar una cuenta.
- Identificación visible de la cuenta activa.
- Reconexión automática con la última cuenta activa.
- Los fallos de red conservan la cuenta y muestran **Reintentar**.
- Migración automática de la cuenta recordada por NICO IPTV 0.3.
- Contraseñas cifradas con AES/GCM mediante Android Keystore.
- Eliminación de las credenciales antiguas en texto plano después de una migración correcta.
- Atrás ya no ejecuta logout ni borra credenciales.
- Doble pulsación de Atrás para salir desde el inicio.
- Restauración de sección, categoría, búsqueda y posición de la lista cuando Android recrea la actividad.
- Regreso desde episodios y reproductor a la lista y posición anteriores.
- Regreso automático a pantalla completa al cerrar Información.
- Normalización del servidor conservando protocolo, host y puerto.
- Eliminación del sufijo erróneo `/0.0.0.0:80` si llega desde una versión anterior.
- Rechazo de `0.0.0.0`, credenciales incrustadas en la URL, consultas y protocolos no HTTP/HTTPS.
- Versión incrementada a `versionCode 4` y `versionName 0.4.0`.

## Archivos modificados

- `app/build.gradle`
- `app/src/main/java/es/nico/iptv/MainActivity.java`
- `app/src/main/java/es/nico/iptv/XtreamClient.java`
- `README.md`

## Archivos añadidos

- `app/src/main/java/es/nico/iptv/AccountStore.java`
- `app/src/main/java/es/nico/iptv/ServerAddress.java`
- `tests/ServerAddressTest.java`
- `CAMBIOS_0.4.md`

## Verificación realizada

- Prueba de listas M3U existente: superada.
- Prueba de normalización de servidor, puertos, rutas y `/0.0.0.0:80`: superada.
- Revisión sintáctica Java: superada.
- Revisión de que ningún evento Atrás, `onStop` u `onDestroy` borra cuentas: superada.
- Compilación Android release: superada con Android SDK 35 y JDK 17.
- Verificación de firma APK v1 y v2: superada.
- Verificación de alineación ZIP: superada.
- Verificación de paquete `es.nico.iptv`, `versionCode 4` y `versionName 0.4.0`: superada.

## Firma de actualización

NICO IPTV 0.4 se ha firmado con una clave nueva: `NicoIPTV-v4-signing.jks`.
Por este motivo se debe desinstalar NICO IPTV 0.3 antes de instalar la versión 0.4.
La nueva clave y sus datos deben conservarse para poder instalar futuras actualizaciones
sobre NICO IPTV 0.4 sin desinstalarla.
