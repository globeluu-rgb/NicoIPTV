# NICO IPTV 0.6

## Ajustes y actualizaciones

- Nueva rueda `⚙ Ajustes` en la pantalla principal.
- Pantalla de ajustes con la versión instalada.
- Botón `Buscar actualización` conectado al repositorio público oficial.
- Comparación de versiones mediante la última publicación de GitHub.
- Aviso con las notas de la nueva versión antes de descargar.
- Descarga del APK únicamente después de la confirmación del usuario.
- Apertura segura del instalador mediante `FileProvider`, sin compartir rutas internas.
- Flujo guiado para autorizar la instalación de aplicaciones desconocidas en Android y Fire TV.
- Reanudación de la instalación al volver a NICO IPTV después de conceder el permiso.

## Compatibilidad y seguridad

- Mantiene Android 6.0 como versión mínima.
- APK release firmado con la misma clave de NICO IPTV 0.4 y 0.5, por lo que puede instalarse como actualización sin borrar cuentas ni favoritos.
- La app consulta exclusivamente `globeluu-rgb/NicoIPTV` y solo acepta archivos APK publicados en GitHub Releases.
- No se incorporan canales, listas, suscripciones ni credenciales.
