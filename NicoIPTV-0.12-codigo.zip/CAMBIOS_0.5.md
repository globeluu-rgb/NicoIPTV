# NICO IPTV 0.5 — interfaz y logo

## Cambios aplicados

- Logo NICO IPTV incorporado como icono de aplicación.
- Pantalla de arranque con el nuevo logo.
- Banner propio para Android TV y Fire TV.
- Portada renovada en azul oscuro y cian, inspirada en la organización por mosaicos de reproductores IPTV para televisión.
- Tres accesos principales grandes: TV en directo, Películas y Series.
- Accesos secundarios para Favoritos, Cuentas, Actualizar y Desconectar.
- Cabeceras de aplicación y de contenido con el logo.
- Foco cian, ampliación suave y navegación con cruceta más visible.
- Se conservan la gestión de cuentas, el cifrado, la sesión persistente, el reproductor y el comportamiento del botón Atrás de la versión 0.4.
- Versión incrementada a `versionCode 5` y `versionName 0.5.0`.

## Archivos principales modificados

- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/es/nico/iptv/MainActivity.java`
- `app/src/main/res/drawable-nodpi/nico_logo.png`
- `app/src/main/res/drawable-nodpi/banner.png`
- `README.md`

## Verificación realizada

- Compilación Android release con Android SDK 35 y JDK 17: superada.
- Firma APK v1 y v2: superada.
- Alineación ZIP: superada.
- Paquete `es.nico.iptv`, `versionCode 5` y `versionName 0.5.0`: verificados.
- Certificado de la versión 0.4 conservado para permitir actualización directa: verificado.
- Pruebas de listas y normalización del servidor: superadas.

## Instalación

- Sobre NICO IPTV 0.4: instalar directamente como actualización.
- Sobre NICO IPTV 0.3: desinstalar primero la 0.3, porque usaba una firma diferente.
