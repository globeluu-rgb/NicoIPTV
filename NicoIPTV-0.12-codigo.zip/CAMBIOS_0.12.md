# NICO IPTV 0.12

- Películas y Series recuperan la vista en cuadrícula.
- El reproductor de películas y episodios incorpora barra de tiempo y botones de retroceso/avance de 10 segundos.
- Izquierda y derecha en el mando retroceden o avanzan 10 segundos en películas y episodios.
- En Fire TV, TV en directo muestra unas 15 filas con fuente y separación más compactas.
- Las categorías de TV muestran el número de canales entre paréntesis.
- Previsualización muda del canal seleccionado en un cuadro superior derecho.
