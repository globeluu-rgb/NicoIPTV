package es.nico.iptv;
import java.io.*;
public class PlaylistTest {
 public static void main(String[] args)throws Exception {
 var list=Playlist.parse(new StringReader("\uFEFF#EXTM3U\n#EXTINF:-1 group-title=\"Noticias, España\",Canal, HD\n../live/a.m3u8\n#EXTINF:-1,Otro\nhttps://example.org/live.ts\n#EXTINF:-1,Mal\nfile:///etc/passwd\n"),"https://example.org/list/index.m3u");
 if(list.size()!=2||!list.get(0).name.equals("Canal, HD")||!list.get(0).group.equals("Noticias, España")||!list.get(0).url.equals("https://example.org/live/a.m3u8")||!list.get(1).group.equals("Sin grupo"))throw new AssertionError();
 if(Playlist.parse(new StringReader("#EXTM3U\n"),"https://example.org/").size()!=0)throw new AssertionError();
 System.out.println("Playlist tests passed: metadata, commas, relative URLs, protocol restrictions, empty playlist.");
 }
}
