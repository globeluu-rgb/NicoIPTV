package es.nico.iptv;

public class ServerAddressTest {
    public static void main(String[] args) throws Exception {
        expect("http://example.com:8080", ServerAddress.normalize(" http://example.com:8080/// "));
        expect("https://example.com/base/path", ServerAddress.normalize("https://example.com/base//path/"));
        expect("http://example.com:8080", ServerAddress.normalize("http://example.com:8080/0.0.0.0:80"));
        reject("http://0.0.0.0");
        reject("file:///tmp/list");
        reject("https://user:password@example.com");
        System.out.println("Server address tests passed: ports, paths, invalid hosts and /0.0.0.0:80.");
    }

    private static void expect(String expected, String actual) {
        if (!expected.equals(actual)) throw new AssertionError(expected + " != " + actual);
    }

    private static void reject(String value) throws Exception {
        try {
            ServerAddress.normalize(value);
            throw new AssertionError("Expected rejection: " + value);
        } catch (IllegalArgumentException expected) { }
    }
}
