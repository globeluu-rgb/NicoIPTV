# NICO IPTV 0.9

## TV en directo más compacta

- Los canales se muestran únicamente como lista; se elimina la cuadrícula.
- Filas más bajas para que se vean al menos siete nombres de canales en un teléfono.
- La cabecera de TV, categorías y canales queda agrupada en una sola línea.
- El buscador permanente desaparece y se sustituye por un icono de lupa.
- Al pulsar la lupa se abre la búsqueda y aparece directamente el teclado.
- El panel de categorías se adapta mejor al ancho de un teléfono.
