# NICO IPTV 0.8

## Nuevo logo

- Nuevo logo azul de NICO IPTV como icono de la aplicación, pantalla de inicio y cabeceras.

## TV en directo

- Categorías visibles permanentemente en una lista situada a la izquierda.
- Canales de la categoría seleccionada en una cuadrícula a la derecha.
- Logos reales de los canales con el logo de NICO IPTV como imagen alternativa.
- Navegación optimizada para Fire TV: izquierda vuelve a categorías, derecha entra en canales y OK reproduce.
- Mantener OK sobre un canal añade o elimina el favorito.
- Búsqueda y filtro de favoritos disponibles en la misma pantalla.
- Botón superior para alternar los canales entre vista de lista y vista de cuadrícula.

## Reproductor

- El vídeo usa modo zoom al entrar en pantalla completa para llenar toda la pantalla del móvil.
- En emisiones con otra proporción de imagen puede recortarse ligeramente el borde para evitar bandas negras.
