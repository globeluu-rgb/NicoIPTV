# NICO IPTV 0.10

## Conexión en Fire TV

- Si Fire OS no puede resolver el dominio del servidor, NICO IPTV reintenta automáticamente.
- Se añade una resolución DNS segura alternativa mediante Cloudflare y Google.
- La conexión conserva el dominio original en la petición para mantener la compatibilidad con servidores Xtream.
- Los canales usan la dirección alternativa obtenida cuando el DNS del dispositivo falla.

## Interfaz

- Se mantienen la lista compacta, los siete canales visibles y el buscador mediante lupa de la versión 0.9.
