# NICO IPTV 0.7

## Actualización de prueba

- Publicación creada para comprobar el botón `Buscar actualización` de NICO IPTV 0.6.
- La aplicación detecta la versión 0.7 desde la publicación oficial, descarga el APK y abre el instalador de Android o Fire TV.
- Mantiene las cuentas y los favoritos al instalarse sobre la versión 0.6.

## Firma

- APK release firmado con la misma clave de NICO IPTV 0.4, 0.5 y 0.6.
