# NICO IPTV 0.6 — cliente Xtream para Android y Fire TV

Aplicación Android nativa para teléfono, tablet, Android TV y Fire TV con Fire OS.
Requiere Android 6.0 o posterior. No funciona en dispositivos que utilicen Vega OS.

La aplicación no incluye canales ni suscripciones. Está diseñada para acceder a
contenido propio o a un servicio autorizado que proporcione credenciales Xtream.

## Funciones

- Inicio de sesión real mediante `player_api.php`: servidor, usuario y contraseña.
- Validación de cuenta, estado y fecha de vencimiento comunicada por el servidor.
- Secciones separadas de TV en directo, películas y series.
- Categorías Xtream para cada sección.
- Temporadas y episodios mediante `get_series_info`.
- Buscador, favoritos y reconexión automática opcional.
- Sección Cuentas con varios perfiles Xtream: añadir, editar, conectar, desconectar y eliminar.
- Contraseñas cifradas mediante Android Keystore y guardadas únicamente en el dispositivo.
- Migración automática de la cuenta recordada por Nico IPTV 0.3.
- La cuenta no se borra si falla Internet, cambia la red, se pulsa Atrás o se cierra la aplicación.
- Restauración automática de la última cuenta activa y opción Reintentar sin perder datos.
- Reproductor Media3 compatible con HLS, DASH y formatos admitidos por el dispositivo.
- Pantalla completa automática a los 3 segundos, con botón manual y controles recuperables con Atrás.
- Botones de información y favoritos dentro del reproductor sin abandonar el canal.
- Interfaz propia de pantalla grande, navegable mediante flechas, OK y Atrás.
- Nueva portada en azul oscuro y cian, con mosaicos grandes para TV, Películas y Series.
- Logo NICO IPTV integrado como icono, pantalla de arranque, cabecera y banner de Android TV.
- Foco ampliado y muy visible para manejar toda la portada con el mando del Fire TV.
- Rueda de Ajustes en la portada con comprobación de nuevas versiones.
- Actualización desde las publicaciones oficiales de GitHub: avisa, muestra los cambios y solo descarga tras confirmación.
- Instalación guiada del APK actualizado en Android y Fire TV, conservando cuentas y favoritos.
- Acceso a Internet declarado en el manifiesto.
- Compatibilidad con servidores HTTP para proveedores antiguos y HTTPS para conexiones cifradas.

## Instalar

En Android, abre `NicoIPTV-0.6.apk` y concede al gestor de archivos permiso para
instalar aplicaciones si el sistema lo solicita.

En Fire TV con Fire OS, se puede transferir el APK con un gestor autorizado o instalarlo
mediante Android Debug Bridge:

    adb connect DIRECCION_IP_DEL_FIRE_TV:5555
    adb install -r NicoIPTV-0.6.apk

Para comprobar actualizaciones desde la aplicación, entra en `⚙ Ajustes` desde la
pantalla principal y pulsa `Buscar actualización`. La primera vez, Android o Fire TV
puede pedir permiso para que NICO IPTV instale aplicaciones desconocidas. La aplicación
no instala nada automáticamente: siempre muestra una confirmación antes de descargar.

En la primera pantalla introduce el servidor completo, por ejemplo
`http://servidor:puerto`, el usuario y la contraseña entregados por el proveedor.
La aplicación construye y consulta las rutas oficiales de la API Xtream. No hace falta
introducir una URL M3U.

## Privacidad

Las cuentas se guardan en el almacenamiento privado de la aplicación, sin copia de seguridad
automática. Las contraseñas se cifran mediante una clave AES creada en Android Keystore.
Solo se eliminan mediante la acción «Eliminar» de la sección Cuentas. «Desconectar» conserva
la cuenta y únicamente cierra la sesión activa.
Con HTTP, las credenciales y el contenido viajan sin cifrar; es preferible HTTPS cuando el
servidor lo permita.

## Límites de esta versión

- No incluye grabación, descarga, control parental, cambio de pista avanzado ni DRM.
- La guía EPG visual completa y los logotipos/caratulas quedan para una versión posterior.
- Algunos proveedores modifican la API Xtream o bloquean determinados agentes de usuario;
  será necesario probar con el servidor real del usuario.
- Los códecs disponibles dependen del hardware del dispositivo.

## Compilar

Abrir el proyecto con Android Studio, JDK 17 y SDK 35, o ejecutar:

    ./gradlew assembleDebug
    ./gradlew lintDebug

El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.
Para distribuirlo de forma estable se debe configurar una firma release y conservar su clave.

Media3 se distribuye bajo Apache License 2.0:
https://github.com/androidx/media/blob/release/LICENSE
