# NICO IPTV 0.16

- El cuadro de información del canal abre su EPG al pulsarlo y solo consulta la programación de ese canal.
- Se elimina el botón independiente de información de la barra del reproductor.
- Se refuerza la carga de logotipos con cabeceras compatibles, rutas relativas y recuperación DNS para servidores HTTP.
- En móvil, TV en directo incorpora dos flechas laterales para subir y bajar de canal.
- El resto de la aplicación mantiene el comportamiento y diseño de la versión 0.15.
