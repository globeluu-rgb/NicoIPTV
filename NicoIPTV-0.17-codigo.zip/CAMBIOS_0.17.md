# NICO IPTV 0.17

- El nombre del programa EPG actual se carga automáticamente después del nombre del canal en la barra inferior.
- Se elimina el texto y la acción de pulsar el cuadro para abrir el EPG.
- En móvil, las flechas de cambio de canal pasan al lado derecho.
- Las flechas móviles se muestran y ocultan junto con la barra inferior de información.
- El resto de la aplicación se mantiene igual que en la versión 0.16.
