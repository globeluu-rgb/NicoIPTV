package es.nico.iptv;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class XtreamClient {
    static final class Category {
        final String id;
        final String name;
        Category(String id, String name) { this.id = id; this.name = name; }
    }

    static final class Item {
        final String id;
        final String name;
        final String categoryId;
        final String extension;
        final String icon;
        final String kind;
        final String directUrl;

        Item(String id, String name, String categoryId, String extension,
             String icon, String kind, String directUrl) {
            this.id = id;
            this.name = name;
            this.categoryId = categoryId;
            this.extension = extension;
            this.icon = icon;
            this.kind = kind;
            this.directUrl = directUrl;
        }
    }

    private final String server;
    private final String username;
    private final String password;

    XtreamClient(String server, String username, String password) throws Exception {
        this.server = ServerAddress.normalize(server);
        this.username = username;
        this.password = password;
    }

    String authenticate() throws Exception {
        JSONObject root = new JSONObject(request(null, null));
        JSONObject user = root.optJSONObject("user_info");
        if (user == null || !"1".equals(String.valueOf(user.opt("auth")))) {
            throw new IOException("Usuario o contraseña rechazados");
        }
        String status = user.optString("status", "Active");
        if (!"Active".equalsIgnoreCase(status)) {
            throw new IOException("Cuenta " + status);
        }
        return user.optString("exp_date", "");
    }

    List<Category> categories(String kind) throws Exception {
        String action;
        if ("live".equals(kind)) action = "get_live_categories";
        else if ("vod".equals(kind)) action = "get_vod_categories";
        else action = "get_series_categories";
        JSONArray data = new JSONArray(request(action, null));
        List<Category> result = new ArrayList<>();
        result.add(new Category("", "Todo"));
        for (int i = 0; i < data.length(); i++) {
            JSONObject row = data.optJSONObject(i);
            if (row != null) result.add(new Category(
                    row.optString("category_id"), row.optString("category_name", "Sin categoría")));
        }
        return result;
    }

    List<Item> items(String kind, String categoryId) throws Exception {
        String action = "live".equals(kind) ? "get_live_streams"
                : "vod".equals(kind) ? "get_vod_streams" : "get_series";
        JSONArray data = new JSONArray(request(action, categoryId));
        List<Item> result = new ArrayList<>();
        for (int i = 0; i < data.length(); i++) {
            JSONObject row = data.optJSONObject(i);
            if (row == null) continue;
            String id = "series".equals(kind) ? row.optString("series_id") : row.optString("stream_id");
            String ext = row.optString("container_extension", "live".equals(kind) ? "ts" : "mp4");
            String icon = "series".equals(kind) ? row.optString("cover") : row.optString("stream_icon");
            result.add(new Item(id, row.optString("name", "Sin nombre"),
                    row.optString("category_id"), ext, icon, kind, null));
        }
        return result;
    }

    List<Item> episodes(String seriesId) throws Exception {
        JSONObject root = new JSONObject(request("get_series_info", null, "series_id", seriesId));
        JSONObject groups = root.optJSONObject("episodes");
        List<Item> result = new ArrayList<>();
        if (groups == null) return result;
        JSONArray seasons = groups.names();
        if (seasons == null) return result;
        for (int s = 0; s < seasons.length(); s++) {
            String season = seasons.optString(s);
            JSONArray episodes = groups.optJSONArray(season);
            if (episodes == null) continue;
            for (int e = 0; e < episodes.length(); e++) {
                JSONObject row = episodes.optJSONObject(e);
                if (row == null) continue;
                String ext = row.optString("container_extension", "mp4");
                String title = row.optString("title", "Episodio " + (e + 1));
                result.add(new Item(row.optString("id"), "T" + season + " · " + title,
                        seriesId, ext, row.optString("movie_image"), "episode", null));
            }
        }
        return result;
    }

    String streamUrl(Item item) {
        if (item.directUrl != null) return item.directUrl;
        String folder = "live".equals(item.kind) ? "live" : "vod".equals(item.kind) ? "movie" : "series";
        return server + "/" + folder + "/" + encodePath(username) + "/" + encodePath(password)
                + "/" + encodePath(item.id) + "." + encodePath(item.extension);
    }

    private String request(String action, String categoryId, String... extra) throws Exception {
        StringBuilder url = new StringBuilder(server).append("/player_api.php?username=")
                .append(query(username)).append("&password=").append(query(password));
        if (action != null) url.append("&action=").append(query(action));
        if (categoryId != null && !categoryId.isEmpty()) url.append("&category_id=").append(query(categoryId));
        for (int i = 0; i + 1 < extra.length; i += 2) {
            url.append('&').append(query(extra[i])).append('=').append(query(extra[i + 1]));
        }
        HttpURLConnection connection = (HttpURLConnection) new URL(url.toString()).openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setRequestProperty("User-Agent", "NicoIPTV/0.4");
        connection.setRequestProperty("Accept", "application/json");
        try {
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("Respuesta HTTP " + code);
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    if (output.size() + read > 25 * 1024 * 1024) throw new IOException("Respuesta demasiado grande");
                    output.write(buffer, 0, read);
                }
                return output.toString(StandardCharsets.UTF_8.name());
            }
        } finally {
            connection.disconnect();
        }
    }

    private String request(String action, String categoryId) throws Exception {
        return request(action, categoryId, new String[0]);
    }

    private static String query(String value) throws Exception {
        return URLEncoder.encode(value, StandardCharsets.UTF_8.name());
    }

    private static String encodePath(String value) {
        return value.replace("%", "%25").replace("/", "%2F").replace("?", "%3F").replace("#", "%23");
    }
}
