package es.nico.iptv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.text.DateFormat;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@UnstableApi
public class MainActivity extends Activity {
    private static final int BG = Color.rgb(2, 8, 20);
    private static final int PANEL = Color.rgb(8, 28, 54);
    private static final int PANEL_LIGHT = Color.rgb(17, 74, 108);
    private static final int ACCENT = Color.rgb(0, 229, 255);
    private static final long AUTO_FULLSCREEN_DELAY_MS = 3000L;
    private static final int IMMERSIVE_FLAGS = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ExecutorService imageWorker = Executors.newFixedThreadPool(3);
    private final Handler playerUiHandler = new Handler(Looper.getMainLooper());
    private final ArrayList<XtreamClient.Item> items = new ArrayList<>();
    private final ArrayList<XtreamClient.Item> visible = new ArrayList<>();
    private final ArrayList<XtreamClient.Category> categories = new ArrayList<>();
    private final Map<String, Bitmap> imageCache = new ConcurrentHashMap<>();
    private Set<String> favorites = new HashSet<>();

    private SharedPreferences prefs;
    private AccountStore accountStore;
    private AccountStore.Account activeAccount;
    private XtreamClient client;
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView playerTitle;
    private LinearLayout playerControls;
    private Button playerFavoriteButton;
    private XtreamClient.Item currentItem;
    private TextView status;
    private TextView updateStatus;
    private Button updateButton;
    private ListView list;
    private ArrayAdapter<String> adapter;
    private ListView liveCategoryList;
    private ArrayAdapter<String> liveCategoryAdapter;
    private GridView liveGrid;
    private BaseAdapter liveGridAdapter;
    private int liveGridColumns = 4;
    private String section = "";
    private String categoryId = "";
    private String categoryName = "Todo";
    private String query = "";
    private boolean favoritesOnly;
    private boolean liveChannelsAsList;
    private boolean playing;
    private boolean immersiveFullscreen;
    private boolean playerControlsVisible;
    private int generation;
    private int listPosition;
    private long lastBackPressed;
    private String screen = "";
    private final Runnable autoFullscreen = () -> {
        if (playing && player != null) enterPlayerFullscreen();
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("nico_xtream", MODE_PRIVATE);
        accountStore = new AccountStore(this);
        favorites = new HashSet<>(prefs.getStringSet("favorites", new HashSet<>()));
        liveChannelsAsList = prefs.getBoolean("live_channels_as_list", false);
        if (state != null) {
            section = state.getString("section", "");
            categoryId = state.getString("category_id", "");
            categoryName = state.getString("category_name", "Todo");
            query = state.getString("query", "");
            favoritesOnly = state.getBoolean("favorites_only", false);
            listPosition = state.getInt("list_position", 0);
        }
        activeAccount = accountStore.active();
        showSplash();
        playerUiHandler.postDelayed(() -> {
            if (isFinishing()) return;
            if (activeAccount != null) connect(activeAccount, true);
            else accountsScreen();
        }, 850L);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout page() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(16), dp(20), dp(12));
        GradientDrawable background = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xff010611, 0xff061a34, 0xff063c59});
        root.setBackground(background);
        setContentView(root);
        return root;
    }

    private ImageView logoView(int size) {
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.nico_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setContentDescription("NICO IPTV");
        logo.setAdjustViewBounds(true);
        logo.setPadding(dp(4), dp(4), dp(4), dp(4));
        logo.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return logo;
    }

    private void showSplash() {
        screen = "splash";
        LinearLayout root = page();
        root.setGravity(Gravity.CENTER);
        root.addView(logoView(300));
        TextView loading = text("Preparando tu televisión…", 16);
        loading.setTextColor(0xffb8eaf5);
        loading.setGravity(Gravity.CENTER);
        root.addView(loading);
    }

    private TextView text(String value, int size) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(Color.WHITE);
        view.setPadding(dp(10), dp(7), dp(10), dp(7));
        return view;
    }

    private StateListDrawable focusBackground() {
        GradientDrawable focused = new GradientDrawable();
        focused.setColors(new int[]{0xff176b92, 0xff0a355d});
        focused.setOrientation(GradientDrawable.Orientation.TL_BR);
        focused.setStroke(dp(4), ACCENT);
        focused.setCornerRadius(dp(14));
        GradientDrawable normal = new GradientDrawable();
        normal.setColors(new int[]{0xff0d3155, 0xff06172e});
        normal.setOrientation(GradientDrawable.Orientation.TL_BR);
        normal.setStroke(dp(1), 0xff285b7f);
        normal.setCornerRadius(dp(14));
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused}, focused);
        states.addState(new int[]{android.R.attr.state_pressed}, focused);
        states.addState(new int[]{}, normal);
        return states;
    }

    private Button button(String value, Runnable action) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setBackground(focusBackground());
        button.setOnClickListener(v -> action.run());
        button.setOnFocusChangeListener((view, focused) -> view.animate()
                .scaleX(focused ? 1.035f : 1f).scaleY(focused ? 1.035f : 1f)
                .setDuration(120L).start());
        return button;
    }

    private void addButton(LinearLayout row, String value, Runnable action, int height) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(height), 1);
        params.setMargins(dp(5), dp(5), dp(5), dp(5));
        row.addView(button(value, action), params);
    }

    private EditText field(LinearLayout parent, String hint, boolean password) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setHintTextColor(0xff8fa5bb);
        input.setTextColor(Color.WHITE);
        input.setSingleLine(true);
        input.setTextSize(18);
        input.setPadding(dp(16), dp(10), dp(16), dp(10));
        input.setBackground(focusBackground());
        input.setInputType(password
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(58));
        params.setMargins(0, dp(6), 0, dp(6));
        parent.addView(input, params);
        return input;
    }

    private void header(LinearLayout root, String subtitle) {
        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        brand.setPadding(0, 0, 0, dp(8));
        brand.addView(logoView(76));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(Gravity.CENTER_VERTICAL);
        brand.addView(copy, new LinearLayout.LayoutParams(0, dp(76), 1));
        TextView title = text("NICO IPTV", 28);
        title.setTextColor(ACCENT);
        title.setTypeface(null, Typeface.BOLD);
        copy.addView(title);
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView sub = text(subtitle, 14);
            sub.setTextColor(0xffa9bace);
            copy.addView(sub);
        }
        root.addView(brand);
    }

    private void addDashboardCard(LinearLayout row, String icon, String title,
                                  String subtitle, Runnable action) {
        String label = icon + "\n" + title + (subtitle.isEmpty() ? "" : "\n" + subtitle);
        Button card = button(label, action);
        card.setGravity(Gravity.CENTER);
        card.setTextSize(18);
        card.setTypeface(null, Typeface.BOLD);
        card.setPadding(dp(10), dp(14), dp(10), dp(14));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -1, 1);
        params.setMargins(dp(7), dp(7), dp(7), dp(7));
        row.addView(card, params);
    }

    private void accountEditor(AccountStore.Account editing) {
        playing = false;
        screen = "editor";
        LinearLayout root = page();
        header(root, editing == null ? "Añadir cuenta Xtream" : "Editar cuenta Xtream");
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(12), dp(20), dp(12), dp(12));
        root.addView(form, new LinearLayout.LayoutParams(-1, 0, 1));
        EditText accountName = field(form, "Nombre de la cuenta", false);
        EditText server = field(form, "Servidor: http://dominio:puerto", false);
        EditText username = field(form, "Usuario", false);
        EditText password = field(form, "Contraseña", true);
        if (editing != null) {
            accountName.setText(editing.name);
            server.setText(editing.server);
            username.setText(editing.username);
            password.setText(editing.password);
        }
        status = text("La aplicación no incluye canales. Usa los datos de un servicio autorizado.", 14);
        form.addView(status);
        LinearLayout actions = new LinearLayout(this);
        form.addView(actions, new LinearLayout.LayoutParams(-1, dp(62)));
        addButton(actions, "Cancelar", this::accountsScreen, 52);
        addButton(actions, "Guardar y conectar", () -> {
            String n = accountName.getText().toString().trim();
            String s = server.getText().toString().trim();
            String u = username.getText().toString().trim();
            String p = password.getText().toString();
            if (s.isEmpty() || u.isEmpty() || p.isEmpty()) {
                status.setText("Completa servidor, usuario y contraseña.");
                return;
            }
            try {
                String normalized = ServerAddress.normalize(s);
                AccountStore.Account saved = accountStore.save(editing == null ? null : editing.id,
                        n.isEmpty() ? u : n, normalized, u, p);
                accountStore.setActive(saved.id);
                activeAccount = saved;
                connect(saved, false);
            } catch (Exception error) {
                status.setText("No se ha podido guardar: " + friendly(error));
            }
        }, 52);
        accountName.requestFocus();
    }

    private void connect(AccountStore.Account account, boolean automatic) {
        int token = ++generation;
        activeAccount = account;
        screen = "connecting";
        LinearLayout root = page();
        header(root, "Conectando con " + account.name + "…");
        ProgressBar progress = new ProgressBar(this);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(80)));
        status = text("Validando acceso Xtream", 17);
        root.addView(status);
        worker.execute(() -> {
            try {
                XtreamClient next = new XtreamClient(account.server, account.username, account.password);
                String expiry = next.authenticate();
                runOnUiThread(() -> {
                    if (token != generation || isFinishing()) return;
                    client = next;
                    accountStore.setActive(account.id);
                    prefs.edit().putString("expiry", expiry).apply();
                    if (automatic && !section.isEmpty()) {
                        contentScreen();
                        loadCategories();
                        loadItems();
                    } else dashboard();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (token != generation || isFinishing()) return;
                    connectionError(account, error, automatic);
                });
            }
        });
    }

    private void connectionError(AccountStore.Account account, Exception error, boolean automatic) {
        client = null;
        screen = "connection_error";
        LinearLayout root = page();
        header(root, "Cuenta guardada: " + account.name);
        TextView explanation = text("No se ha podido conectar: " + friendly(error)
                + "\n\nLa cuenta sigue guardada. Comprueba la red o inténtalo de nuevo.", 17);
        root.addView(explanation, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout actions = new LinearLayout(this);
        root.addView(actions);
        addButton(actions, "Reintentar", () -> connect(account, true), 58);
        addButton(actions, "Cuentas", this::accountsScreen, 58);
        actions.getChildAt(0).requestFocus();
    }

    private void accountsScreen() {
        generation++;
        playing = false;
        screen = "accounts";
        LinearLayout root = page();
        header(root, "Cuentas Xtream guardadas");
        List<AccountStore.Account> accounts = accountStore.all();
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        root.addView(rows, new LinearLayout.LayoutParams(-1, 0, 1));
        for (AccountStore.Account account : accounts) {
            boolean active = activeAccount != null && activeAccount.id.equals(account.id);
            Button row = button((active ? "●  " : "○  ") + account.name + "\n"
                    + account.username + " · " + account.server, () -> accountActions(account));
            row.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(76));
            params.setMargins(0, dp(4), 0, dp(4));
            rows.addView(row, params);
        }
        LinearLayout bottom = new LinearLayout(this);
        root.addView(bottom);
        addButton(bottom, "+ Añadir cuenta", () -> accountEditor(null), 58);
        if (client != null) addButton(bottom, "‹ Volver al inicio", this::dashboard, 58);
        if (rows.getChildCount() > 0) rows.getChildAt(0).requestFocus();
        else bottom.getChildAt(0).requestFocus();
    }

    private void accountActions(AccountStore.Account account) {
        boolean connected = activeAccount != null && activeAccount.id.equals(account.id) && client != null;
        String[] actions = connected
                ? new String[]{"Volver al inicio", "Editar", "Desconectar", "Eliminar"}
                : new String[]{"Conectar", "Editar", "Eliminar"};
        new AlertDialog.Builder(this).setTitle(account.name).setItems(actions, (dialog, which) -> {
            String action = actions[which];
            if ("Volver al inicio".equals(action)) dashboard();
            else if ("Conectar".equals(action)) {
                accountStore.setActive(account.id);
                activeAccount = account;
                connect(account, false);
            } else if ("Editar".equals(action)) accountEditor(account);
            else if ("Desconectar".equals(action)) confirmDisconnect();
            else confirmDelete(account);
        }).show();
    }

    private void confirmDelete(AccountStore.Account account) {
        new AlertDialog.Builder(this).setTitle("Eliminar cuenta")
                .setMessage("¿Eliminar “" + account.name + "” de este dispositivo?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    try {
                        if (activeAccount != null && activeAccount.id.equals(account.id)) {
                            releasePlayer();
                            client = null;
                            activeAccount = null;
                        }
                        accountStore.delete(account.id);
                        accountsScreen();
                    } catch (Exception error) {
                        message("No se ha podido eliminar: " + friendly(error));
                    }
                }).show();
    }

    private void dashboard() {
        playing = false;
        screen = "dashboard";
        section = "";
        LinearLayout root = page();
        header(root, activeAccount == null ? "Cuenta conectada" : activeAccount.name);
        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        root.addView(cards, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout main = new LinearLayout(this);
        cards.addView(main, new LinearLayout.LayoutParams(-1, 0, 1));
        addDashboardCard(main, "▣", "TV EN DIRECTO", "Canales y categorías",
                () -> openSection("live", false));
        addDashboardCard(main, "▶", "PELÍCULAS", "Vídeo bajo demanda",
                () -> openSection("vod", false));
        addDashboardCard(main, "▤", "SERIES", "Temporadas y episodios",
                () -> openSection("series", false));
        LinearLayout shortcuts = new LinearLayout(this);
        cards.addView(shortcuts, new LinearLayout.LayoutParams(-1, dp(78)));
        addButton(shortcuts, "★ Favoritos", this::favoritesMenu, 66);
        addButton(shortcuts, "♙ Cuentas", this::accountsScreen, 66);
        addButton(shortcuts, "⚙ Ajustes", this::settingsScreen, 66);
        addButton(shortcuts, "⏻ Desconectar", this::confirmDisconnect, 66);
        String expiry = prefs.getString("expiry", "");
        if (!expiry.isEmpty() && !"0".equals(expiry)) {
            try {
                String date = DateFormat.getDateInstance().format(new Date(Long.parseLong(expiry) * 1000L));
                root.addView(text("Vencimiento indicado por el servidor: " + date, 12));
            } catch (NumberFormatException ignored) { }
        }
        main.getChildAt(0).requestFocus();
    }

    private void settingsScreen() {
        playing = false;
        screen = "settings";
        LinearLayout root = page();
        header(root, "Ajustes");

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(8), dp(12), dp(8), dp(12));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView version = text("Versión instalada: " + installedVersion(), 18);
        version.setTypeface(null, Typeface.BOLD);
        content.addView(version);
        TextView explanation = text("Las actualizaciones se comprueban en el repositorio oficial de NICO IPTV. La app no descarga nada hasta que tú lo confirmas.", 15);
        explanation.setTextColor(0xffb8cce0);
        content.addView(explanation);

        updateStatus = text("Pulsa el botón para comprobar si existe una versión nueva.", 15);
        updateStatus.setTextColor(0xffb8eaf5);
        content.addView(updateStatus);

        updateButton = button("Buscar actualización", this::checkForUpdate);
        LinearLayout.LayoutParams updateParams = new LinearLayout.LayoutParams(-1, dp(64));
        updateParams.setMargins(0, dp(12), 0, dp(8));
        content.addView(updateButton, updateParams);

        Button back = button("‹ Volver al inicio", this::dashboard);
        root.addView(back, new LinearLayout.LayoutParams(-1, dp(58)));
        updateButton.requestFocus();
    }

    private AppUpdater.Callback updaterCallback() {
        return new AppUpdater.Callback() {
            @Override public void onStatus(String message, boolean busy) {
                if (updateStatus != null) updateStatus.setText(message);
                if (updateButton != null) updateButton.setEnabled(!busy);
            }

            @Override public void onUpdateReady(String version, String notes, String downloadUrl) {
                onStatus("Nueva versión disponible: " + version, false);
                String detail = notes == null || notes.trim().isEmpty()
                        ? "Hay una nueva versión disponible."
                        : notes.trim();
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Actualizar a NICO IPTV " + version)
                        .setMessage(detail)
                        .setNegativeButton("Ahora no", null)
                        .setPositiveButton("Descargar e instalar", (dialog, which) ->
                                AppUpdater.downloadAndInstall(worker, MainActivity.this,
                                        version, downloadUrl, updaterCallback()))
                        .show();
            }

            @Override public void onCurrent() {
                onStatus("NICO IPTV está actualizado (versión " + installedVersion() + ").", false);
            }

            @Override public void onError(String message) {
                onStatus("No se ha podido comprobar: " + message, false);
            }
        };
    }

    private void checkForUpdate() {
        AppUpdater.check(worker, this, updaterCallback());
    }

    private String installedVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
            return "0.6.0";
        }
    }

    private void favoritesMenu() {
        new AlertDialog.Builder(this).setTitle("Favoritos")
                .setItems(new String[]{"TV en directo", "Películas", "Series"}, (dialog, which) -> {
                    String[] kinds = {"live", "vod", "series"};
                    openSection(kinds[which], true);
                }).show();
    }

    private void openSection(String kind, boolean onlyFavorites) {
        section = kind;
        favoritesOnly = onlyFavorites;
        categoryId = "";
        categoryName = "Todo";
        query = "";
        listPosition = 0;
        contentScreen();
        loadCategories();
        loadItems();
    }

    private String sectionName() {
        if ("live".equals(section)) return "TV en directo";
        if ("vod".equals(section)) return "Películas";
        if ("series".equals(section)) return "Series";
        return "Contenido";
    }

    private void contentScreen() {
        if ("live".equals(section)) {
            liveContentScreen();
            return;
        }
        liveCategoryList = null;
        liveCategoryAdapter = null;
        liveGrid = null;
        liveGridAdapter = null;
        screen = "content";
        LinearLayout root = page();
        LinearLayout top = new LinearLayout(this);
        root.addView(top);
        Button back = button("‹ Inicio", this::dashboard);
        top.addView(back, new LinearLayout.LayoutParams(dp(120), dp(52)));
        ImageView sectionLogo = logoView(48);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(58), dp(52));
        logoParams.setMargins(dp(8), 0, dp(4), 0);
        top.addView(sectionLogo, logoParams);
        TextView sectionTitle = text((favoritesOnly ? "★ " : "") + sectionName(), 24);
        sectionTitle.setTypeface(null, Typeface.BOLD);
        sectionTitle.setTextColor(ACCENT);
        top.addView(sectionTitle, new LinearLayout.LayoutParams(0, dp(52), 1));

        LinearLayout tools = new LinearLayout(this);
        root.addView(tools);
        addButton(tools, "Categoría: " + categoryName, this::chooseCategory, 52);
        addButton(tools, favoritesOnly ? "Ver todo" : "Solo favoritos", () -> {
            favoritesOnly = !favoritesOnly;
            contentScreen();
            filterItems();
        }, 52);

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Buscar en " + sectionName().toLowerCase(Locale.ROOT) + "…");
        search.setHintTextColor(0xff8fa5bb);
        search.setTextColor(Color.WHITE);
        search.setText(query);
        search.setBackground(focusBackground());
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(55)));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {
                query = value.toString();
                filterItems();
            }
            @Override public void afterTextChanged(Editable editable) { }
        });
        status = text("Cargando…", 14);
        root.addView(status);
        list = new ListView(this);
        list.setDividerHeight(dp(5));
        list.setSelector(focusBackground());
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList<>()) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(Color.WHITE);
                view.setTextSize(18);
                view.setMinHeight(dp(58));
                return view;
            }
        };
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        list.setOnItemClickListener((parent, view, position, id) -> selectItem(visible.get(position)));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            toggleFavorite(visible.get(position));
            return true;
        });
        root.addView(text("OK: abrir · Mantener OK: favorito · Atrás: inicio", 12));
        if (!visible.isEmpty()) {
            list.setSelection(Math.min(listPosition, visible.size() - 1));
            list.requestFocus();
        } else back.requestFocus();
    }

    private void liveContentScreen() {
        screen = "content";
        list = null;
        adapter = null;
        LinearLayout root = page();

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(56)));
        Button back = button("‹ Inicio", this::dashboard);
        top.addView(back, new LinearLayout.LayoutParams(dp(120), dp(52)));
        ImageView sectionLogo = logoView(48);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(58), dp(52));
        logoParams.setMargins(dp(8), 0, dp(4), 0);
        top.addView(sectionLogo, logoParams);
        TextView title = text((favoritesOnly ? "★ " : "") + "TV EN DIRECTO", 24);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(ACCENT);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        Button favoritesButton = button(favoritesOnly ? "Ver todos" : "☆ Favoritos", () -> {
            favoritesOnly = !favoritesOnly;
            liveContentScreen();
            filterItems();
        });
        top.addView(favoritesButton, new LinearLayout.LayoutParams(dp(150), dp(50)));

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Buscar canal…");
        search.setHintTextColor(0xff8fa5bb);
        search.setTextColor(Color.WHITE);
        search.setText(query);
        search.setBackground(focusBackground());
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence value, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {
                query = value.toString();
                filterItems();
            }
            @Override public void afterTextChanged(Editable editable) { }
        });

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout categoryPanel = new LinearLayout(this);
        categoryPanel.setOrientation(LinearLayout.VERTICAL);
        categoryPanel.setPadding(0, dp(6), dp(10), 0);
        int panelWidth = Math.max(dp(235), Math.min(dp(370),
                (int) (getResources().getDisplayMetrics().widthPixels * 0.30f)));
        body.addView(categoryPanel, new LinearLayout.LayoutParams(panelWidth, -1));
        TextView categoryTitle = text("CATEGORÍAS", 18);
        categoryTitle.setTextColor(0xffffd21c);
        categoryTitle.setTypeface(null, Typeface.BOLD);
        categoryPanel.addView(categoryTitle);
        liveCategoryList = new ListView(this);
        liveCategoryList.setDividerHeight(dp(2));
        liveCategoryList.setSelector(focusBackground());
        liveCategoryAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>()) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(position < categories.size()
                        && categories.get(position).id.equals(categoryId) ? 0xffffd21c : Color.WHITE);
                view.setTextSize(17);
                view.setTypeface(null, position < categories.size()
                        && categories.get(position).id.equals(categoryId) ? Typeface.BOLD : Typeface.NORMAL);
                view.setMinHeight(dp(58));
                view.setGravity(Gravity.CENTER_VERTICAL);
                view.setSingleLine(false);
                return view;
            }
        };
        liveCategoryList.setAdapter(liveCategoryAdapter);
        categoryPanel.addView(liveCategoryList, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout channelPanel = new LinearLayout(this);
        channelPanel.setOrientation(LinearLayout.VERTICAL);
        channelPanel.setPadding(dp(8), dp(6), 0, 0);
        body.addView(channelPanel, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout channelHeader = new LinearLayout(this);
        channelHeader.setGravity(Gravity.CENTER_VERTICAL);
        channelPanel.addView(channelHeader, new LinearLayout.LayoutParams(-1, dp(52)));
        status = text("Cargando canales…", 14);
        status.setTextColor(0xffb8eaf5);
        channelHeader.addView(status, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button viewMode = button(liveChannelsAsList ? "Vista: Lista" : "Vista: Cuadrícula", () -> {
            liveChannelsAsList = !liveChannelsAsList;
            prefs.edit().putBoolean("live_channels_as_list", liveChannelsAsList).apply();
            liveContentScreen();
            filterItems();
            if (liveGrid != null && !visible.isEmpty()) {
                liveGrid.setSelection(Math.min(listPosition, visible.size() - 1));
                liveGrid.requestFocus();
            }
        });
        channelHeader.addView(viewMode, new LinearLayout.LayoutParams(dp(170), dp(46)));
        liveGrid = new GridView(this);
        int available = Math.max(dp(420), getResources().getDisplayMetrics().widthPixels - panelWidth);
        liveGridColumns = liveChannelsAsList ? 1
                : Math.max(2, Math.min(5, available / dp(185)));
        liveGrid.setNumColumns(liveGridColumns);
        liveGrid.setHorizontalSpacing(dp(8));
        liveGrid.setVerticalSpacing(dp(8));
        liveGrid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        liveGrid.setSelector(focusBackground());
        liveGridAdapter = new LiveChannelAdapter();
        liveGrid.setAdapter(liveGridAdapter);
        channelPanel.addView(liveGrid, new LinearLayout.LayoutParams(-1, 0, 1));

        liveCategoryList.setOnItemClickListener((parent, view, position, id) -> selectLiveCategory(position));
        liveCategoryList.setOnKeyListener((view, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                    && liveGrid != null && !visible.isEmpty()) {
                liveGrid.setSelection(Math.min(listPosition, visible.size() - 1));
                liveGrid.requestFocus();
                return true;
            }
            return false;
        });
        liveGrid.setOnKeyListener((view, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                    && liveGrid.getSelectedItemPosition() % liveGridColumns == 0) {
                liveCategoryList.requestFocus();
                return true;
            }
            return false;
        });
        liveGrid.setOnItemClickListener((parent, view, position, id) -> selectItem(visible.get(position)));
        liveGrid.setOnItemLongClickListener((parent, view, position, id) -> {
            toggleFavorite(visible.get(position));
            return true;
        });
        refreshLiveCategories();
        if (!visible.isEmpty()) {
            liveGrid.setSelection(Math.min(listPosition, visible.size() - 1));
            liveGrid.requestFocus();
        } else {
            liveCategoryList.requestFocus();
        }
        root.addView(text("← Categorías · → Canales · OK: reproducir · Mantener OK: favorito", 12));
    }

    private void refreshLiveCategories() {
        if (liveCategoryAdapter == null) return;
        liveCategoryAdapter.clear();
        if (categories.isEmpty()) liveCategoryAdapter.add("Cargando categorías…");
        else for (XtreamClient.Category category : categories) liveCategoryAdapter.add(category.name);
        liveCategoryAdapter.notifyDataSetChanged();
        if (liveCategoryList != null && !categories.isEmpty()) {
            for (int i = 0; i < categories.size(); i++) {
                if (categories.get(i).id.equals(categoryId)) {
                    liveCategoryList.setSelection(i);
                    break;
                }
            }
        }
    }

    private void selectLiveCategory(int position) {
        if (position < 0 || position >= categories.size()) return;
        XtreamClient.Category selected = categories.get(position);
        categoryId = selected.id;
        categoryName = selected.name;
        listPosition = 0;
        refreshLiveCategories();
        loadItems();
    }

    private final class LiveChannelAdapter extends BaseAdapter {
        @Override public int getCount() { return visible.size(); }
        @Override public XtreamClient.Item getItem(int position) { return visible.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
            LinearLayout card;
            ImageView image;
            TextView name;
            if (convertView instanceof LinearLayout && convertView.getTag() instanceof Object[]) {
                card = (LinearLayout) convertView;
                Object[] holder = (Object[]) card.getTag();
                image = (ImageView) holder[0];
                name = (TextView) holder[1];
            } else {
                card = new LinearLayout(MainActivity.this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setGravity(Gravity.CENTER);
                card.setPadding(dp(6), dp(6), dp(6), dp(6));
                card.setBackground(focusBackground());
                image = new ImageView(MainActivity.this);
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                image.setBackgroundColor(0xff05090f);
                card.addView(image, new LinearLayout.LayoutParams(-1, dp(112)));
                name = text("", 14);
                name.setGravity(Gravity.CENTER);
                name.setMaxLines(2);
                name.setEllipsize(TextUtils.TruncateAt.END);
                card.addView(name, new LinearLayout.LayoutParams(-1, dp(54)));
                card.setTag(new Object[]{image, name});
            }
            XtreamClient.Item item = getItem(position);
            card.setOrientation(liveChannelsAsList ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
            card.setGravity(liveChannelsAsList ? Gravity.CENTER_VERTICAL : Gravity.CENTER);
            if (liveChannelsAsList) {
                image.setLayoutParams(new LinearLayout.LayoutParams(dp(108), dp(72)));
                name.setGravity(Gravity.CENTER_VERTICAL);
                name.setTextSize(17);
                name.setLayoutParams(new LinearLayout.LayoutParams(0, dp(76), 1));
                card.setMinimumHeight(dp(82));
            } else {
                image.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(112)));
                name.setGravity(Gravity.CENTER);
                name.setTextSize(14);
                name.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(54)));
                card.setMinimumHeight(0);
            }
            boolean favorite = favorites.contains(favoriteKey(item));
            name.setText((favorite ? "★ " : "") + item.name);
            showChannelIcon(image, item.icon);
            return card;
        }
    }

    private void showChannelIcon(ImageView view, String iconUrl) {
        if (iconUrl == null || iconUrl.trim().isEmpty()) {
            view.setTag(null);
            view.setImageResource(R.drawable.nico_logo);
            return;
        }
        view.setTag(iconUrl);
        Bitmap cached = imageCache.get(iconUrl);
        if (cached != null) {
            view.setImageBitmap(cached);
            return;
        }
        view.setImageResource(R.drawable.nico_logo);
        imageWorker.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(iconUrl).openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(12000);
                connection.setRequestProperty("User-Agent", "NicoIPTV/0.8");
                try (InputStream input = connection.getInputStream()) {
                    Bitmap bitmap = BitmapFactory.decodeStream(input);
                    if (bitmap == null) return;
                    imageCache.put(iconUrl, bitmap);
                    runOnUiThread(() -> {
                        if (iconUrl.equals(view.getTag())) view.setImageBitmap(bitmap);
                    });
                }
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void loadCategories() {
        String requestedSection = section;
        worker.execute(() -> {
            try {
                List<XtreamClient.Category> result = client.categories(requestedSection);
                runOnUiThread(() -> {
                    if (isFinishing() || !requestedSection.equals(section)) return;
                    categories.clear();
                    categories.addAll(result);
                    refreshLiveCategories();
                });
            } catch (Exception error) {
                runOnUiThread(() -> message("No se han podido cargar las categorías: " + friendly(error)));
            }
        });
    }

    private void loadItems() {
        int token = ++generation;
        String requestedSection = section;
        String requestedCategory = categoryId;
        if (status != null) status.setText("Cargando " + sectionName().toLowerCase(Locale.ROOT) + "…");
        worker.execute(() -> {
            try {
                List<XtreamClient.Item> result = client.items(requestedSection, requestedCategory);
                runOnUiThread(() -> {
                    if (token != generation || isFinishing() || !requestedSection.equals(section)) return;
                    items.clear();
                    items.addAll(result);
                    filterItems();
                    if (list != null && !visible.isEmpty()) {
                        list.setSelection(Math.min(listPosition, visible.size() - 1));
                        list.requestFocus();
                    } else if (liveGrid != null && !visible.isEmpty()) {
                        liveGrid.setSelection(Math.min(listPosition, visible.size() - 1));
                        liveGrid.requestFocus();
                    }
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (token == generation && status != null) status.setText("Error: " + friendly(error));
                });
            }
        });
    }

    private void chooseCategory() {
        if (categories.isEmpty()) {
            Toast.makeText(this, "Las categorías aún se están cargando", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[categories.size()];
        for (int i = 0; i < categories.size(); i++) names[i] = categories.get(i).name;
        new AlertDialog.Builder(this).setTitle("Selecciona una categoría")
                .setItems(names, (dialog, which) -> {
                    XtreamClient.Category selected = categories.get(which);
                    categoryId = selected.id;
                    categoryName = selected.name;
                    contentScreen();
                    loadItems();
                }).show();
    }

    private void filterItems() {
        if (adapter == null && liveGridAdapter == null) return;
        visible.clear();
        ArrayList<String> labels = new ArrayList<>();
        String needle = query.toLowerCase(Locale.ROOT);
        for (XtreamClient.Item item : items) {
            boolean favorite = favorites.contains(favoriteKey(item));
            if ((!favoritesOnly || favorite) && item.name.toLowerCase(Locale.ROOT).contains(needle)) {
                visible.add(item);
                labels.add((favorite ? "★  " : "") + item.name);
            }
        }
        if (adapter != null) {
            adapter.clear();
            adapter.addAll(labels);
        }
        if (liveGridAdapter != null) liveGridAdapter.notifyDataSetChanged();
        if (status != null) status.setText(visible.size() + " elementos · " + categoryName);
    }

    private void selectItem(XtreamClient.Item item) {
        if (list != null) listPosition = Math.max(0, list.getSelectedItemPosition());
        else if (liveGrid != null) listPosition = Math.max(0, liveGrid.getSelectedItemPosition());
        if ("series".equals(item.kind)) loadEpisodes(item);
        else play(item);
    }

    private void loadEpisodes(XtreamClient.Item series) {
        int token = ++generation;
        screen = "episodes";
        LinearLayout root = page();
        header(root, series.name);
        status = text("Cargando episodios…", 16);
        root.addView(status);
        worker.execute(() -> {
            try {
                List<XtreamClient.Item> episodes = client.episodes(series.id);
                runOnUiThread(() -> {
                    if (token != generation || isFinishing()) return;
                    if (episodes.isEmpty()) {
                        status.setText("El servidor no ha devuelto episodios.");
                        return;
                    }
                    String[] names = new String[episodes.size()];
                    for (int i = 0; i < episodes.size(); i++) names[i] = episodes.get(i).name;
                    ListView episodeList = new ListView(this);
                    ArrayAdapter<String> episodeAdapter = new ArrayAdapter<String>(this,
                            android.R.layout.simple_list_item_1, names) {
                        @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                            TextView view = (TextView) super.getView(position, convertView, parent);
                            view.setTextColor(Color.WHITE);
                            view.setTextSize(18);
                            view.setMinHeight(dp(58));
                            return view;
                        }
                    };
                    episodeList.setAdapter(episodeAdapter);
                    episodeList.setSelector(focusBackground());
                    root.addView(episodeList, new LinearLayout.LayoutParams(-1, 0, 1));
                    Button back = button("‹ Volver a series", () -> {
                        contentScreen();
                        filterItems();
                    if (list != null && !visible.isEmpty()) list.setSelection(Math.min(listPosition, visible.size() - 1));
                    });
                    root.addView(back, new LinearLayout.LayoutParams(-1, dp(56)));
                    episodeList.setOnItemClickListener((p, v, position, id) -> play(episodes.get(position)));
                    status.setText(episodes.size() + " episodios");
                    episodeList.requestFocus();
                });
            } catch (Exception error) {
                runOnUiThread(() -> status.setText("Error: " + friendly(error)));
            }
        });
    }

    private String favoriteKey(XtreamClient.Item item) {
        return item.kind + ":" + item.id;
    }

    private void toggleFavorite(XtreamClient.Item item) {
        String key = favoriteKey(item);
        boolean added = favorites.add(key);
        if (!added) favorites.remove(key);
        prefs.edit().putStringSet("favorites", new HashSet<>(favorites)).apply();
        filterItems();
        refreshPlayerFavoriteButton();
        Toast.makeText(this, added ? "Añadido a favoritos" : "Eliminado de favoritos",
                Toast.LENGTH_SHORT).show();
    }

    private void play(XtreamClient.Item item) {
        releasePlayer();
        playing = true;
        screen = "player";
        currentItem = item;
        immersiveFullscreen = false;
        playerControlsVisible = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);
        LinearLayout root = page();
        root.setPadding(0, 0, 0, 0);
        playerTitle = text(item.name, 18);
        playerTitle.setBackgroundColor(PANEL);
        root.addView(playerTitle);
        playerView = new PlayerView(this);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setOnClickListener(v -> {
            if (immersiveFullscreen && !playerControlsVisible) showPlayerControls();
            else enterPlayerFullscreen();
        });
        root.addView(playerView, new LinearLayout.LayoutParams(-1, 0, 1));
        playerControls = new LinearLayout(this);
        playerControls.setOrientation(LinearLayout.VERTICAL);
        playerControls.setPadding(dp(8), dp(4), dp(8), dp(8));
        playerControls.setBackgroundColor(PANEL);
        root.addView(playerControls);
        LinearLayout mainActions = new LinearLayout(this);
        LinearLayout extraActions = new LinearLayout(this);
        playerControls.addView(mainActions);
        playerControls.addView(extraActions);
        addButton(mainActions, "‹ Volver", this::returnFromPlayer, 50);
        addButton(mainActions, "ⓘ Información", () -> showItemInfo(item), 50);
        playerFavoriteButton = button("", () -> toggleFavorite(item));
        LinearLayout.LayoutParams favoriteParams = new LinearLayout.LayoutParams(0, dp(50), 1);
        favoriteParams.setMargins(dp(5), dp(5), dp(5), dp(5));
        mainActions.addView(playerFavoriteButton, favoriteParams);
        refreshPlayerFavoriteButton();
        addButton(extraActions, "⛶ Pantalla completa", this::enterPlayerFullscreen, 50);
        addButton(extraActions, "↻ Reintentar", () -> play(item), 50);
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException error) {
                playerTitle.setText(item.name + " · No se puede reproducir este formato o enlace.");
            }
        });
        player.setMediaItem(MediaItem.fromUri(client.streamUrl(item)));
        player.prepare();
        player.play();
        playerView.requestFocus();
        playerUiHandler.postDelayed(autoFullscreen, AUTO_FULLSCREEN_DELAY_MS);
    }

    private void enterPlayerFullscreen() {
        if (!playing || playerView == null) return;
        playerUiHandler.removeCallbacks(autoFullscreen);
        immersiveFullscreen = true;
        playerControlsVisible = false;
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        if (playerTitle != null) playerTitle.setVisibility(View.GONE);
        if (playerControls != null) playerControls.setVisibility(View.GONE);
        getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE_FLAGS);
        playerView.requestFocus();
    }

    private void showPlayerControls() {
        if (!playing || playerView == null) return;
        playerUiHandler.removeCallbacks(autoFullscreen);
        immersiveFullscreen = true;
        playerControlsVisible = true;
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        if (playerTitle != null) playerTitle.setVisibility(View.VISIBLE);
        if (playerControls != null) playerControls.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE_FLAGS);
        refreshPlayerFavoriteButton();
        if (playerFavoriteButton != null) playerFavoriteButton.requestFocus();
    }

    private void refreshPlayerFavoriteButton() {
        if (playerFavoriteButton == null || currentItem == null) return;
        boolean favorite = favorites.contains(favoriteKey(currentItem));
        playerFavoriteButton.setText(favorite ? "★ Quitar favorito" : "☆ Añadir favorito");
    }

    private void showItemInfo(XtreamClient.Item item) {
        String type = "live".equals(item.kind) ? "Canal en directo"
                : "vod".equals(item.kind) ? "Película" : "Episodio";
        boolean favorite = favorites.contains(favoriteKey(item));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(item.name)
                .setMessage("Tipo: " + type + "\nFavorito: " + (favorite ? "Sí" : "No"))
                .setPositiveButton("Cerrar", null)
                .create();
        dialog.setOnDismissListener(ignored -> {
            if (playing) enterPlayerFullscreen();
        });
        dialog.show();
    }

    private void returnFromPlayer() {
        playerUiHandler.removeCallbacks(autoFullscreen);
        releasePlayer();
        playing = false;
        immersiveFullscreen = false;
        playerControlsVisible = false;
        currentItem = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);
        contentScreen();
        filterItems();
        if (list != null && !visible.isEmpty()) {
            list.setSelection(Math.min(listPosition, visible.size() - 1));
            list.requestFocus();
        } else if (liveGrid != null && !visible.isEmpty()) {
            liveGrid.setSelection(Math.min(listPosition, visible.size() - 1));
            liveGrid.requestFocus();
        }
    }

    private void releasePlayer() {
        playerUiHandler.removeCallbacks(autoFullscreen);
        if (player != null) {
            if (playerView != null) playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }

    private void confirmDisconnect() {
        new AlertDialog.Builder(this).setTitle("Desconectar cuenta")
                .setMessage("La cuenta seguirá guardada y podrás conectarla de nuevo desde Cuentas.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Desconectar", (dialog, which) -> {
                    generation++;
                    releasePlayer();
                    client = null;
                    activeAccount = null;
                    accountStore.setActive(null);
                    accountsScreen();
                }).show();
    }

    private void message(String value) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this).setTitle("Nico IPTV").setMessage(value)
                .setPositiveButton("Aceptar", null).show();
    }

    private String friendly(Exception error) {
        String value = error.getMessage();
        return value == null || value.trim().isEmpty() ? "error de conexión" : value;
    }

    @Override public void onBackPressed() {
        if (playing && immersiveFullscreen && !playerControlsVisible) showPlayerControls();
        else if (playing) returnFromPlayer();
        else if ("episodes".equals(screen)) {
            contentScreen();
            filterItems();
            if (list != null && !visible.isEmpty()) {
                list.setSelection(Math.min(listPosition, visible.size() - 1));
                list.requestFocus();
            }
        }
        else if ("settings".equals(screen)) dashboard();
        else if ("editor".equals(screen) || "connection_error".equals(screen)) accountsScreen();
        else if ("accounts".equals(screen) && client != null) dashboard();
        else if (!section.isEmpty()) dashboard();
        else if (client != null) {
            long now = System.currentTimeMillis();
            if (now - lastBackPressed < 1800L) super.onBackPressed();
            else {
                lastBackPressed = now;
                Toast.makeText(this, "Pulsa otra vez para salir", Toast.LENGTH_SHORT).show();
            }
        } else {
            long now = System.currentTimeMillis();
            if (now - lastBackPressed < 1800L) super.onBackPressed();
            else {
                lastBackPressed = now;
                Toast.makeText(this, "Pulsa otra vez para salir", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && playing && immersiveFullscreen) {
            getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE_FLAGS);
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (player != null) {
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
                if (player.isPlaying()) player.pause(); else player.play();
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY) { player.play(); return true; }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE) { player.pause(); return true; }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override protected void onResume() {
        super.onResume();
        AppUpdater.resumePendingInstall(this, updaterCallback());
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("section", section);
        outState.putString("category_id", categoryId);
        outState.putString("category_name", categoryName);
        outState.putString("query", query);
        outState.putBoolean("favorites_only", favoritesOnly);
        if (list != null && list.getSelectedItemPosition() >= 0) {
            listPosition = list.getSelectedItemPosition();
        } else if (liveGrid != null && liveGrid.getSelectedItemPosition() >= 0) {
            listPosition = liveGrid.getSelectedItemPosition();
        }
        outState.putInt("list_position", listPosition);
    }

    @Override protected void onDestroy() {
        generation++;
        releasePlayer();
        worker.shutdownNow();
        imageWorker.shutdownNow();
        super.onDestroy();
    }
}
