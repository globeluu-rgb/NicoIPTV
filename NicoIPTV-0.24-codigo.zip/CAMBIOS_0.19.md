# NICO IPTV 0.19

- Se recupera el núcleo de reproducción estable de la versión 0.13 para Fire TV.
- Se elimina el renderizador personalizado introducido en la versión 0.14.
- Se restaura el búfer estable de la 0.13: entre 12 y 50 segundos, con 5 segundos de búfer anterior.
- Se recuperan también los tiempos de detección y recuperación de señal de la 0.13.
- La previsualización vuelve a usar `PlayerView`, como en la 0.13, en lugar de `TextureView`.
- Se conservan la barra inferior, el EPG automático, los logos, las flechas móviles y las mejoras de memoria de la 0.18.
