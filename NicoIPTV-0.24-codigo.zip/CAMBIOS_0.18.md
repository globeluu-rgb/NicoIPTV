# NICO IPTV 0.18

- Corrección específica para Fire TV de los bloqueos después de varios minutos.
- La memoria de logos queda limitada y se libera automáticamente cuando el dispositivo necesita memoria.
- La cola de descarga de logos también queda limitada para evitar saturación al recorrer muchos canales.
- La previsualización usa un búfer ligero, evita reiniciarse si el canal seleccionado no cambia y se libera al mandar la aplicación al fondo.
- El reproductor principal usa un búfer adaptado a Fire TV para reducir el consumo de memoria.
- El detector de imagen congelada evita recuperaciones duplicadas y reinicios demasiado frecuentes.
- Al volver a la aplicación, el canal reanuda la reproducción y reactiva correctamente su vigilancia.
- Se conserva el diseño, el EPG automático, los logos y los controles actuales.
