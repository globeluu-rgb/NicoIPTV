# NICO IPTV 0.20

- Se incorporan los nuevos iconos azules de TV en directo, películas y series en la pantalla principal.
- Se precargan los primeros logotipos de canales al entrar en una categoría.
- El título del programa actual permite abrir la descripción completa del EPG con OK o un toque.
- La navegación vertical permanece en la lista de categorías y ya no salta a los canales al llegar abajo.
- En móvil, el primer toque previsualiza el canal y el segundo abre la reproducción; tocar otro canal cambia la previsualización.
- Se mantiene sin cambios el núcleo de reproducción estable recuperado en la versión 0.19.
