# NICO IPTV 0.24

- Recupera la base estable de reproducción de la versión 0.20.
- La aplicación abre primero la pantalla de cuentas y no conecta automáticamente.
- Ajustes está disponible antes de conectar a un servidor Xtream.
- La búsqueda de actualizaciones funciona sin haber conectado ninguna cuenta.
- Nuevo selector de versiones publicadas para reinstalar o intentar volver a una versión anterior.
- La versión 0.20 aparece identificada como base estable.

Nota: Android normalmente no permite instalar una versión con un código inferior encima de otra
más nueva. En ese caso el sistema puede exigir desinstalar primero la aplicación actual, lo que
puede borrar las cuentas guardadas localmente.
