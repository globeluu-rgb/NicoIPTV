package es.nico.iptv;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

final class XtreamClient {
    static final class Category {
        final String id;
        final String name;
        Category(String id, String name) { this.id = id; this.name = name; }
    }

    static final class Item {
        final String id;
        final String name;
        final String categoryId;
        final String extension;
        final String icon;
        final String kind;
        final String directUrl;

        Item(String id, String name, String categoryId, String extension,
             String icon, String kind, String directUrl) {
            this.id = id;
            this.name = name;
            this.categoryId = categoryId;
            this.extension = extension;
            this.icon = icon;
            this.kind = kind;
            this.directUrl = directUrl;
        }
    }

    private final String server;
    private final URI serverUri;
    private final String username;
    private final String password;
    private volatile String connectionServer;

    XtreamClient(String server, String username, String password) throws Exception {
        this.server = ServerAddress.normalize(server);
        this.serverUri = new URI(this.server);
        this.connectionServer = this.server;
        this.username = username;
        this.password = password;
    }

    String authenticate() throws Exception {
        JSONObject root = new JSONObject(request(null, null));
        JSONObject user = root.optJSONObject("user_info");
        if (user == null || !"1".equals(String.valueOf(user.opt("auth")))) {
            throw new IOException("Usuario o contraseña rechazados");
        }
        String status = user.optString("status", "Active");
        if (!"Active".equalsIgnoreCase(status)) {
            throw new IOException("Cuenta " + status);
        }
        return user.optString("exp_date", "");
    }

    List<Category> categories(String kind) throws Exception {
        String action;
        if ("live".equals(kind)) action = "get_live_categories";
        else if ("vod".equals(kind)) action = "get_vod_categories";
        else action = "get_series_categories";
        JSONArray data = new JSONArray(request(action, null));
        List<Category> result = new ArrayList<>();
        result.add(new Category("", "Todo"));
        for (int i = 0; i < data.length(); i++) {
            JSONObject row = data.optJSONObject(i);
            if (row != null) result.add(new Category(
                    row.optString("category_id"), row.optString("category_name", "Sin categoría")));
        }
        return result;
    }

    List<Item> items(String kind, String categoryId) throws Exception {
        String action = "live".equals(kind) ? "get_live_streams"
                : "vod".equals(kind) ? "get_vod_streams" : "get_series";
        JSONArray data = new JSONArray(request(action, categoryId));
        List<Item> result = new ArrayList<>();
        for (int i = 0; i < data.length(); i++) {
            JSONObject row = data.optJSONObject(i);
            if (row == null) continue;
            String id = "series".equals(kind) ? row.optString("series_id") : row.optString("stream_id");
            String ext = row.optString("container_extension", "live".equals(kind) ? "ts" : "mp4");
            String icon = "series".equals(kind) ? row.optString("cover") : row.optString("stream_icon");
            result.add(new Item(id, row.optString("name", "Sin nombre"),
                    row.optString("category_id"), ext, icon, kind, null));
        }
        return result;
    }

    List<Item> episodes(String seriesId) throws Exception {
        JSONObject root = new JSONObject(request("get_series_info", null, "series_id", seriesId));
        JSONObject groups = root.optJSONObject("episodes");
        List<Item> result = new ArrayList<>();
        if (groups == null) return result;
        JSONArray seasons = groups.names();
        if (seasons == null) return result;
        for (int s = 0; s < seasons.length(); s++) {
            String season = seasons.optString(s);
            JSONArray episodes = groups.optJSONArray(season);
            if (episodes == null) continue;
            for (int e = 0; e < episodes.length(); e++) {
                JSONObject row = episodes.optJSONObject(e);
                if (row == null) continue;
                String ext = row.optString("container_extension", "mp4");
                String title = row.optString("title", "Episodio " + (e + 1));
                result.add(new Item(row.optString("id"), "T" + season + " · " + title,
                        seriesId, ext, row.optString("movie_image"), "episode", null));
            }
        }
        return result;
    }

    String streamUrl(Item item) {
        if (item.directUrl != null) return item.directUrl;
        String folder = "live".equals(item.kind) ? "live" : "vod".equals(item.kind) ? "movie" : "series";
        return connectionServer + "/" + folder + "/" + encodePath(username) + "/" + encodePath(password)
                + "/" + encodePath(item.id) + "." + encodePath(item.extension);
    }

    private String request(String action, String categoryId, String... extra) throws Exception {
        try {
            return executeRequest(connectionServer, action, categoryId, extra);
        } catch (Exception error) {
            if (!isDnsFailure(error) || !"http".equalsIgnoreCase(serverUri.getScheme())) throw error;
            String address = resolveIpv4(serverUri.getHost());
            connectionServer = serverWithAddress(address);
            return executeRequest(connectionServer, action, categoryId, extra);
        }
    }

    private String executeRequest(String base, String action, String categoryId,
                                  String... extra) throws Exception {
        StringBuilder url = new StringBuilder(base).append("/player_api.php?username=")
                .append(query(username)).append("&password=").append(query(password));
        if (action != null) url.append("&action=").append(query(action));
        if (categoryId != null && !categoryId.isEmpty()) url.append("&category_id=").append(query(categoryId));
        for (int i = 0; i + 1 < extra.length; i += 2) {
            url.append('&').append(query(extra[i])).append('=').append(query(extra[i + 1]));
        }
        HttpURLConnection connection = (HttpURLConnection) new URL(url.toString()).openConnection();
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setRequestProperty("User-Agent", "NicoIPTV/0.14");
        connection.setRequestProperty("Accept", "application/json");
        if (!base.equals(server)) connection.setRequestProperty("Host", originalAuthority());
        try {
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("Respuesta HTTP " + code);
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    if (output.size() + read > 25 * 1024 * 1024) throw new IOException("Respuesta demasiado grande");
                    output.write(buffer, 0, read);
                }
                return output.toString(StandardCharsets.UTF_8.name());
            }
        } finally {
            connection.disconnect();
        }
    }

    private String serverWithAddress(String address) {
        StringBuilder value = new StringBuilder(serverUri.getScheme()).append("://").append(address);
        if (serverUri.getPort() >= 0) value.append(':').append(serverUri.getPort());
        String path = serverUri.getRawPath();
        if (path != null && !path.isEmpty()) value.append(path);
        return value.toString();
    }

    private String originalAuthority() {
        if (serverUri.getPort() < 0) return serverUri.getHost();
        return serverUri.getHost() + ":" + serverUri.getPort();
    }

    private static boolean isDnsFailure(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof UnknownHostException) return true;
            String message = current.getMessage();
            if (message != null) {
                String lower = message.toLowerCase(java.util.Locale.ROOT);
                if (lower.contains("unable to resolve host") || lower.contains("no address associated")) {
                    return true;
                }
            }
            current = current.getCause();
        }
        return false;
    }

    private static String resolveIpv4(String host) throws Exception {
        try {
            for (InetAddress address : InetAddress.getAllByName(host)) {
                if (address instanceof Inet4Address) return address.getHostAddress();
            }
        } catch (Exception ignored) { }

        String encoded = URLEncoder.encode(host, StandardCharsets.UTF_8.name());
        String[] endpoints = {
                "https://cloudflare-dns.com/dns-query?name=" + encoded + "&type=A",
                "https://dns.google/resolve?name=" + encoded + "&type=A"
        };
        Exception last = null;
        for (String endpoint : endpoints) {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(10000);
                connection.setRequestProperty("Accept", "application/dns-json");
                connection.setRequestProperty("User-Agent", "NicoIPTV/0.14");
                if (connection.getResponseCode() != 200) continue;
                String json;
                try (InputStream input = connection.getInputStream();
                     ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[4096];
                    int read;
                    while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
                    json = output.toString(StandardCharsets.UTF_8.name());
                }
                JSONArray answers = new JSONObject(json).optJSONArray("Answer");
                if (answers == null) continue;
                for (int i = 0; i < answers.length(); i++) {
                    JSONObject answer = answers.optJSONObject(i);
                    if (answer == null || answer.optInt("type") != 1) continue;
                    String address = answer.optString("data", "");
                    if (isIpv4(address)) return address;
                }
            } catch (Exception error) {
                last = error;
            } finally {
                if (connection != null) connection.disconnect();
            }
        }
        UnknownHostException failure = new UnknownHostException(
                "No se puede resolver el servidor ni con el DNS alternativo");
        if (last != null) failure.initCause(last);
        throw failure;
    }

    private static boolean isIpv4(String value) {
        String[] parts = value.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            try {
                int number = Integer.parseInt(part);
                if (number < 0 || number > 255 || !String.valueOf(number).equals(part)) return false;
            } catch (NumberFormatException error) {
                return false;
            }
        }
        return true;
    }

    private String request(String action, String categoryId) throws Exception {
        return request(action, categoryId, new String[0]);
    }

    private static String query(String value) throws Exception {
        return URLEncoder.encode(value, StandardCharsets.UTF_8.name());
    }

    private static String encodePath(String value) {
        return value.replace("%", "%25").replace("/", "%2F").replace("?", "%3F").replace("#", "%23");
    }
}
