# NICO IPTV 0.14

- TV en directo usa en móvil el mismo modo lista compacto de Fire TV.
- Previsualización disponible también en móvil, con sonido.
- Previsualización basada en TextureView para mejorar compatibilidad con modelos Fire TV.
- Imagen del canal como alternativa si el dispositivo no puede mostrar el segundo vídeo.
- Selección automática de decodificadores alternativos del dispositivo para vídeo y audio.
- Barra inferior superpuesta con información del canal y cinco controles compactos.
- Mantiene el búfer reforzado y la recuperación automática del directo.
