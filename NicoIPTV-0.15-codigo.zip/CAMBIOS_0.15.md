# NICO IPTV 0.15

- Corrige el fallo de arranque de la versión 0.14.
- El APK se genera íntegramente con Gradle, sin reconstrucción manual de recursos ni clases DEX.
- Mantiene el diseño compacto común para móvil y Fire TV.
- Mantiene la previsualización con sonido, el respaldo visual y la barra inferior de información.
- Conserva la recuperación automática de emisiones congeladas y el búfer reforzado.

